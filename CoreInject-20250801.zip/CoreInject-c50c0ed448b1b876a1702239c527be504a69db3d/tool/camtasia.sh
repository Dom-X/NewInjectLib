/usr/bin/codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLExporter
/usr/bin/codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLThumbnailer